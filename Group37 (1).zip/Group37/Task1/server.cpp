#define SERVER_IP "127.0.0.1"
#define BUFFER_SIZE 1024

#include <algorithm>
#include <cstddef>
#include <iostream>
#include <string>
#include <cstdlib>
#include <cstdio>
#include <map>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <cstring>
#include <netinet/in.h>
#include <thread>
#include <vector>
#include <mutex>
#include "./helper/serverHelper.cpp"
#include <unistd.h> 
#include <signal.h> 

std::mutex console_mutex;

using namespace std;

// All helper functions implemented in serverHelper.cpp
void start(int);
void closeAndExit(void);
void help(void);
void encryptDecrypt(char *data, size_t len);
void clear();

ostream& operator<<(std::ostream& ss, const DroneInformation& drone) {
    ss << "Current Telemetry Data of Drone\n";
    ss << "x = " << drone.x << " " << ", y = " << drone.y << " " << ", z = " << drone.z << endl;
    ss << "vx = " << drone.vx << " " << ", vy = " << drone.vy << " " << ", vz = " << drone.vz << endl;
    ss << "state = " << drone.state << endl;
    return ss;
}

void sendControlCommand(string UUID, string mode);
void handleTelemetryData(int, int);
void startTelemetryServer(int);
string getCurrentTime(void);
void makeDataDirectories(void);
void parseTelemetryData(const std::string&, int);
void QUICServer(string UUID);
int verbose = 0;
int TCPConnected = 0;
int numDrones;

int main(){
    makeDataDirectories();
    cout << "Drone server application started\n";
    cout << "Type `help` for receiving help\n";
    cout << ">> ";

    string input;

    // Starting with adding support for just 1 drone
    int telemetryServersStarted = 0;

    while((cin >> input)){
        if(input == "start"){
            if(startExecuted){
                cerr << "Start can only be executed once.\n";
                continue;
            }
            startExecuted = 1;
            cin >> numDrones;
            start(numDrones);
            for(int i = 0; i < numDrones; i++) drones[8080 + 3*i] = new DroneInformation();
        }else if(input == "quit" && !startExecuted){
            exit(0);
        }else if(input == "help"){
            help();
        }

        if(!startExecuted){
            cout << "First execute `start`\n>> ";
            continue;
        }

        if(input == "quit") sendControlCommand(input, "quit");
        else if(input == "clear") clear();
        else if(input == "help") help();
        else if(input == "stop"){ 
            string temp;
            cin >> temp;
            if(temp == "print") verbose = 0;
            else cout << "No such command avalaible. Type `help` to get list of avalaible commands.\n";
        }else if(input == "resume"){
            string temp;
            cin >> temp;
            if(temp == "print") verbose = 1;
            else cout << "No such command avalaible. Type `help` to get list of avalaible commands.\n";
        }else{
            if(input == "list"){
                cout << "UUIDs of avalaible drones\n";
                for(int i = 0; i < numDrones; i++) cout << 8080 + 3*i << endl;
            }else if(input == "show"){
                cout << "Displaying Last Received Drone Information\n";
                for(auto i: drones) cout << i.first << endl << *(i.second) << endl << endl;
            }else if(all_of(input.begin(), input.end(), ::isdigit)){
                string function;
                cin >> function;
                if(function == "set"){ 
                    sendControlCommand(input, "control");
                }else if(function == "fetch"){
                    // On a parallel thread we also need to execute the python server instruction
                    std::ofstream outfile;
                    outfile.open("./FileData/" + input, std::ios_base::app);
                    std::string currentTime = getCurrentTime();
                    
                    outfile << "\n" << "\n" << currentTime << "\n";

                    std::thread QUICServerThread(QUICServer, input);
                    QUICServerThread.detach();
                    sendControlCommand(input, "fetch");
                }else if(function == "show"){ 
                    for(auto i: drones){ 
                        if(i.first == stoi(input)) cout << *(i.second);
                    }
                }else{
                    cout << "No such command avalaible. Type `help` to get list of avalaible commands.\n";                    
                }
            }else{
                cout << "No such command avalaible. Type `help` to get list of avalaible commands.\n";
            }
        }
        if(!telemetryServersStarted && startExecuted){ 
            telemetryServersStarted = 1;
            cout << "\nStarting TCP connections for Receiving Telemetry Data\n";

            vector<int> ports;
            for(int i = 0; i < numDrones; i++) ports.push_back(8081 + 3*i);

            std::vector<std::thread> telemetryServerThreads;
            for (int port : ports) telemetryServerThreads.push_back(std::thread(startTelemetryServer, port));

            // Wait for threads to complete, this signifies all threads have accepted connection with respective drones!
            for (auto& t : telemetryServerThreads) {
                t.join();
            }

            TCPConnected = 1;
        }
        cout << ">> ";
    }

    return 0;
}

void sendControlCommand(string UUID, string mode){
    if(mode == "quit"){
        // Send quit command to all drones, wait for 1 second and exit
        for(int i = 0; i < numDrones; i++){
            // We need to open an UDP connection, send value and close connection
            int control_socket;
            struct sockaddr_in droneAddress;

            // Initialise drone address struct
            droneAddress.sin_family = AF_INET;
            droneAddress.sin_port = htons(8080 + 3*i);
            if(inet_pton(AF_INET, SERVER_IP, &droneAddress.sin_addr) <= 0){
                cerr << "Invalid Address/Adress not supported\n";
                exit(1);
            }

            // Creating sockets
            control_socket = socket(AF_INET, SOCK_DGRAM, 0);
            if(control_socket < 0){
                cerr << "Error creating Control Socket\n";
            }

            char buffer[BUFFER_SIZE];
            strncpy(buffer, mode.c_str(), BUFFER_SIZE);
            
            encryptDecrypt(buffer, mode.length());
            if(sendto(control_socket, buffer, mode.length(), 0, (struct sockaddr*)&droneAddress, sizeof(droneAddress)) < 0){
                cerr << "Error sending exit command\n";
            }else{
                cout << "Exit command sent to Drone " << UUID << ": " << mode << endl;
            }

            close(control_socket);
        }

        sleep(1);
        exit(0);
    }

    string command;
    getline(cin, command);
    if (command.empty()) command = "fetch";

    // We need to open an UDP connection, send value and close connection
    int control_socket;
    struct sockaddr_in droneAddress;

    // Initialise drone address struct
    droneAddress.sin_family = AF_INET;
    droneAddress.sin_port = htons(stoi(UUID));
    if(inet_pton(AF_INET, SERVER_IP, &droneAddress.sin_addr) <= 0){
        cerr << "Invalid Address/Adress not supported\n";
        exit(1);
    }

    // Creating sockets
    control_socket = socket(AF_INET, SOCK_DGRAM, 0);
    if(control_socket < 0){
        cerr << "Error creating Control Socket\n";
    }

    char buffer[BUFFER_SIZE];
    strncpy(buffer, command.c_str(), BUFFER_SIZE);
    
    encryptDecrypt(buffer, command.length());
    if(sendto(control_socket, buffer, command.length(), 0, (struct sockaddr*)&droneAddress, sizeof(droneAddress)) < 0){
        cerr << "Error sending control command\n";
    }else{
        cout << "Control command sent to Drone " << UUID << ": " << command << endl;
    }

    close(control_socket);
}

void startTelemetryServer(int portNumber){
    int serverSocket, clientSocket;
    struct sockaddr_in serverAddr, clientAddr;
    socklen_t addrSize;

    serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket < 0) {
        std::cerr << "Failed to create socket for port: " << portNumber << std::endl;
        return;
    }

    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(portNumber);
    serverAddr.sin_addr.s_addr = INADDR_ANY;

    if (bind(serverSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) < 0) {
        std::cerr << "Binding failed on port: " << portNumber << std::endl;
        return;
    }

    if (listen(serverSocket, 1) == 0) {
        lock_guard<std::mutex> lock(console_mutex);
        std::cout << "Listening on port: " << portNumber << std::endl;
        console_mutex.unlock();
    } else {
        std::cerr << "Failed to listen on port: " << portNumber << std::endl;
        return;
    }

    while (true) {
        addrSize = sizeof(clientAddr);
        clientSocket = accept(serverSocket, (struct sockaddr*)&clientAddr, &addrSize);
        if (clientSocket < 0) {
            std::cerr << "Failed to accept connection on port: " << portNumber << std::endl;
            continue;
        }else{
            std::cout << "Client connected on port: " << portNumber << std::endl;
            std::thread clientThread(handleTelemetryData, clientSocket, portNumber);
            clientThread.detach();
            break;
        }
    }

    close(serverSocket);
}

void handleTelemetryData(int clientSocket, int portNumber) {
    char buffer[BUFFER_SIZE];
    std::ofstream file;
    file.open("./TelemetryData/server_data_" + std::to_string(portNumber) + ".txt", std::ios_base::out | std::ios_base::trunc);
    
    while (true) {
        memset(buffer, 0, BUFFER_SIZE);
        ssize_t bytesRead = read(clientSocket, buffer, sizeof(buffer) - 1);
        if (bytesRead <= 0) {
            std::cout << "Drone disconnected from port: " << portNumber << std::endl;
            close(clientSocket);
            break;
        }
        encryptDecrypt(buffer, bytesRead);
        std::string data(buffer);
        std::string currentTime = getCurrentTime();

        // Set the values in the telemetry data struct
        parseTelemetryData(data, portNumber - 1);

        // Log received data with current timestamp unless stopped printing
        file << currentTime << "\n" << data << std::endl << endl;
        if(verbose) std::cout << "Received telemetry data from drone on port " << portNumber << " at " << currentTime << ": " << data << std::endl;
    }

    file.close();
}

void QUICServer(string UUID){
    // Call server python command
    string command = "python3 helper/QUICHelper/examples/http3_server.py --certificate helper/QUICHelper/tests/ssl_cert.pem --private-key helper/QUICHelper/tests/ssl_key.pem --port " + to_string(stoi(UUID) + 2) + "> /dev/null 2>&1";
    system(command.c_str());
}

#define XOR_KEY 0xBB
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <chrono>
#include <cstdlib>   // For system()
#include <cstdio>    // For remove()
#include <iomanip>
#include <cstring>
#include <string>
#include <map>
#ifdef _WIN32
    #include <direct.h>
    #define mkdir _mkdir
#else
    #include <sys/stat.h>
    #include <sys/types.h>
#endif

using namespace std;

struct DroneInformation{
    int x;
    int y;
    int z;
    int vx;
    int vy;
    int vz;
    string state;
};
map<int, DroneInformation*> drones;

void makeDataDirectories(void) {
    std::string dirName = "./TelemetryData";
    #ifdef _WIN32
    if (mkdir(dirName.c_str()) != 0) {
    #else
    if (mkdir(dirName.c_str(), 0755) != 0) {
    #endif
        if (errno != EEXIST) std::cerr << "Error creating directory: " << strerror(errno) << std::endl;
    } else {
        std::cout << "Directory created: " << dirName << std::endl;
    }

    dirName = "./FileData";
    #ifdef _WIN32
    if (mkdir(dirName.c_str()) != 0) {
    #else
    if (mkdir(dirName.c_str(), 0755) != 0) {
    #endif
        if (errno != EEXIST) std::cerr << "Error creating directory: " << strerror(errno) << std::endl;
    } else {
        std::cout << "Directory created: " << dirName << std::endl;
    }
}

int startExecuted = 0;

void help(void){
    if(!startExecuted){
        cout << "Start by executing `start n` to create drone applications.\n";
    }
    cout << "User commands supported:\n";
    cout << "            - quit: To quit the program\n";
    cout << "            - start n: Creates n drone application, ./drone{i} all with a UUID. Each drone application needs to be seperately started in it's own terminal.\n";
    cout << "            - list: Lists all active drones along with their UUID.\n";
    cout << "            - show: Lists last received telemetry data of all drones.\n";
    cout << "            - stop print: This stops printing of telemetry information.\n";
    cout << "            - resume print: This resumes printing of telemetry information.\n";
    cout << "            - clear: Clears the interface.\n";
    cout << "            - [UUID] set [pos/vel] [x/y/z] [data]: This is the implementation of the control commands. The commands will be sent to the particular drone application via the specific port it's active on, via a UDP connection.\n";
    cout << "            - [UUID] set state [Sleeping/Active]: This is implementation of state of drone (another control command). Avalaible                 states are Flying (Default), Stopped. In Stopped state, the position of the drone does not get updated with time.\n";
    cout << "            - [UUID] fetch: This fetch command is sent over a UDP connection. Following this a data file is sent from the particular drone application to the user application, via a QUIC connection. This is stored in the FileData Folder\n";
    cout << "            - [UUID] show: Shows last received telemetry data of this particular drone.\n";
    return;
}

void start(int n) {
    /*
        start function is called when the user first calls `start n` upon the startup of the server.
        This opens the drone.cpp file, modifies the `#define UUID 0` line to a new UUID.
        Calls the g++ compiler to compile it to `drone{i}` executable file.
    */

    // Open drone.cpp, read file into a string, close drone.cpp
    std::ifstream inputFile("drone.cpp");    
    if (!inputFile.is_open()) {
        std::cerr << "Error: Could not open drone.cpp" << std::endl;
        return;
    }
    std::stringstream buffer;
    buffer << inputFile.rdbuf();
    std::string fileContents = buffer.str();
    inputFile.close();

    // Find the line containing "#define UUID"
    std::size_t uuidPos = fileContents.find("#define UUID");

    // Iterate from 1 to n
    for (int i = 1; i <= n; ++i) {
        int uuid = 8080 + 3*(i-1);

        // Create a copy of the file content and modify the UUID line
        std::string modifiedFileContents = fileContents;
        std::size_t endOfLine = modifiedFileContents.find('\n', uuidPos);
        if (endOfLine == std::string::npos) {
            endOfLine = modifiedFileContents.length();
        }

        // Replace the line with the new #define UUID value
        std::string newUUIDLine = "#define UUID " + std::to_string(uuid);
        modifiedFileContents.replace(uuidPos, endOfLine - uuidPos, newUUIDLine);

        // Generate the filename for drone_i.cpp
        std::string sourceFileName = "drone_" + std::to_string(i) + ".cpp";
        
        // Write the modified content to drone_i.cpp
        std::ofstream outputFile(sourceFileName);
        if (!outputFile.is_open()) {
            std::cerr << "Error: Could not create output file for " << sourceFileName << std::endl;
            continue;
        }

        outputFile << modifiedFileContents;
        outputFile.close();

        // Compile the generated source file using g++
        std::string compileCommand = "g++ " + sourceFileName + " -o drone_" + std::to_string(i);
        int compileResult = system(compileCommand.c_str());

        // Check if compilation was successful
        if (compileResult != 0) {
            std::cerr << "Error: Compilation failed for " << sourceFileName << std::endl;
            continue;
        }

        // Delete the source file after successful compilation
        if (std::remove(sourceFileName.c_str()) != 0) {
            std::cerr << "Error: Could not delete " << sourceFileName << std::endl;
        } else {
            std::cout << "Successfully compiled and deleted " << sourceFileName << std::endl;
        }
    }

    std::cout << "Finished generating, compiling, and cleaning up drone_* files." << std::endl;
    std::cout << "\nStart the drone applications individually." << std::endl;
}

void encryptDecrypt(char *data, size_t len){
    for(size_t i = 0; i < len; i++) data[i] ^= XOR_KEY;
}

void closeAndExit(void){
    // TBD
    exit(0);
}

// Function to get the current timestamp as a formatted string
std::string getCurrentTime() {
    auto now = std::chrono::system_clock::now();
    auto timeT = std::chrono::system_clock::to_time_t(now);
    auto localTime = std::localtime(&timeT);

    std::stringstream ss;
    ss << std::put_time(localTime, "%Y-%m-%d %H:%M:%S");  // Format: YYYY-MM-DD HH:MM:SS
    return ss.str();
}

void clear(void) {
    #ifdef _WIN32
        std::system("cls");  // Windows command to clear screen
    #else
        std::system("clear");  // Unix/Linux/MacOS command to clear screen
    #endif
}

void parseTelemetryData(const std::string& telemetryData, int droneID) {
    std::istringstream ss(telemetryData);
    std::string line;

    DroneInformation* droneInfo = new DroneInformation();
    std::getline(ss, line);

    std::getline(ss, line);  // "x = value, y = value, z = value"
    sscanf(line.c_str(), "x = %d , y = %d , z = %d", &droneInfo->x, &droneInfo->y, &droneInfo->z);
    std::getline(ss, line);  // "vx = value, vy = value, vz = value"
    sscanf(line.c_str(), "vx = %d , vy = %d , vz = %d", &droneInfo->vx, &droneInfo->vy, &droneInfo->vz);

    std::getline(ss, line);  // "state = value"
    std::size_t pos = line.find("state = ");
    if (pos != std::string::npos) {
        droneInfo->state = line.substr(pos + 8);  
        droneInfo->state.erase(0, droneInfo->state.find_first_not_of(' '));  
        droneInfo->state.erase(droneInfo->state.find_last_not_of(' ') + 1);  
    }

    drones[droneID] = droneInfo;
}
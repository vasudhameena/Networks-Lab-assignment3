#define UUID 0 // This will be populated by `start n call of server`

/*
    Each drone application is uniquely identifies by it's UUID. This UUID defines the TCP, UDP, and QUIC connection port 
    number for that drone.

    Each drone supports and executes the following functionality:
        - 1 thread is responsible for maintaining the drone_state struct. It updates the values of position every second,
            based on the velocity
        - 1 thread is responsible for handling the control commands sent over the UDP connection including fetch command
            for sending data to the server
        - 1 thread is responsible for handling the actual drone behaviour which includes changing the position based on the
            velocity
*/

#include <ostream>
#include <cstddef>
#include <mutex>
#include <netinet/in.h>
#include <sys/socket.h>
#include <iostream>
#include <arpa/inet.h>
#include <thread>
#include <unistd.h>
#include <string>
#include <fstream>
#include <cstring>
#include <sstream>
#include <cstdlib>
#include <ctime>

#ifdef _WIN32
    #include <direct.h>
    #define mkdir _mkdir
#else
    #include <sys/stat.h>
    #include <sys/types.h>
#endif

using namespace std;

#define XOR_KEY 0xBB
#define BUFFER_SIZE 1024
#define SERVER_IP "127.0.0.1"

struct DroneInformation{
    int x;
    int y;
    int z;
    int vx;
    int vy;
    int vz;
    string state;
};
DroneInformation drone;
std::mutex console_mutex;

void updateDroneInformation(string);
string DroneState(void);
void encryptDecrypt(char *, size_t);
void handleControlCommands(int);
void sendTelemetryData(int);
void sendFileToServer(void);
void flyDrone(void);

int main(){
    std::string dirName = "./DroneData";
    #ifdef _WIN32
    if (mkdir(dirName.c_str()) != 0) {
    #else
    if (mkdir(dirName.c_str(), 0755) != 0) {
    #endif
        if (errno != EEXIST) std::cerr << "Error creating directory: " << strerror(errno) << std::endl;
    } else {
        std::cout << "Directory created: " << dirName << std::endl;
    }

    drone.state = "Flying";

    cout << "Drone Activated with UUID: " << UUID << endl;

    std::thread Drone(flyDrone);
    Drone.detach();

    // Control Instructions Implementation
    /*
        For control instruction the drone needs to continously listen on port UUID
        Any instruction sent from the server on this port needs to be parsed accordingly
    */
    // Creating control socket
    int control_socket;
    struct sockaddr_in controlSocket;
    controlSocket.sin_family = AF_INET;
    controlSocket.sin_addr.s_addr = INADDR_ANY;
    control_socket = socket(AF_INET, SOCK_DGRAM, 0);
    if(control_socket < 0){
        cerr << "Error creating control listener socket" << endl;
        return 1;
    }

    // Bind control socket to port
    controlSocket.sin_port = htons(UUID);
    if(bind(control_socket, (struct sockaddr*)&controlSocket, sizeof(controlSocket)) < 0){
        cerr << "Error binding control socket to " << UUID << endl;
        return 1;
    }

    // Telemetry Data Implementation
    /*
        For sending telemetry data, the drone acts as a client.
        So we need to make a socket and send data on that socket, on port number UUID + 1
    */
    // Creating Telemetry TCP socket
    int telemetryDataSocket;
    struct sockaddr_in telemetrySocketAddr;
    telemetryDataSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (telemetryDataSocket < 0) {
        std::cerr << "Failed to create socket" << std::endl;
        return 1;
    }

    // Connecting to Server (since TCP)
    string serverIP = SERVER_IP;
    telemetrySocketAddr.sin_family = AF_INET;
    telemetrySocketAddr.sin_port = htons(UUID + 1);
    telemetrySocketAddr.sin_addr.s_addr = inet_addr(serverIP.c_str());
    if (connect(telemetryDataSocket, (struct sockaddr*)&telemetrySocketAddr, sizeof(telemetrySocketAddr)) < 0) {
        std::cerr << "Connection failed to server on port: " << UUID + 1 << std::endl;
        return 1;
    }

    // Seperate threads for parsing Control Commands and sending Telemetry Data
    std::thread controlThread(handleControlCommands, control_socket);
    std::thread telemtryThread(sendTelemetryData, telemetryDataSocket);

    // Wait for all threads to end before exiting
    controlThread.join();
    close(telemetryDataSocket);
    close(control_socket);

    return 0;
}

void flyDrone(void){
    while(true){
        if(drone.state == "Flying"){
            drone.x += drone.vx;
            drone.y += drone.vy;
            drone.z += drone.vz;
        }

        // We also need to populate the data in DroneData 
        // (Note that since this is just a simulation and actual expectation is that DroneData/UUID will be populated by actual video or something)
        std::ofstream outfile("./DroneData/" + to_string(UUID), std::ios::out);
        // Generate some random characters and write them to the file
        for (int i = 0; i < 1000; ++i) {
            char random_char = static_cast<char>(std::rand() % 95 + 32);
            outfile << random_char;
        }
        outfile.close();

        std::this_thread::sleep_for(std::chrono::seconds(1));
    }


}

void sendTelemetryData(int telemetryDataSocket){
    while (true) {
        string data = DroneState();
        // Convert std::string to mutable char*
        size_t len = data.size();
        char* mutableData = new char[len + 1]; 
        std::strcpy(mutableData, data.c_str());

        encryptDecrypt(mutableData, len);  // Encrypt the mutable data
        ssize_t bytesSent = send(telemetryDataSocket, mutableData, data.size(), 0);
        std::cout << "Sent telemetry data to server:\n" << data << "on port: " << UUID + 1 << std::endl << std::endl;

        std::this_thread::sleep_for(std::chrono::seconds(5));
    }
}

void updateDroneInformation(string command){
    size_t first = command.find_first_not_of(' ');
    command = (first == std::string::npos) ? "" : command.substr(first);

    cout << "Updating drone with command: " << command << "\n";

    std::istringstream iss(command);
    string part1, axis, state;
    int value;

    iss >> part1;
    cout << part1;

    if(part1 == "state"){
        iss >> state;
        drone.state = state;
    }else if(part1 == "pos" || part1 == "vel"){
        iss >> axis >> value;
        if(part1 == "pos"){
            if(axis == "x") drone.x = value;
            else if(axis == "y") drone.y = value;
            else if(axis == "z") drone.z = value;
        }else if(part1 == "vel"){
            if(axis == "x") drone.vx = value;
            else if(axis == "y") drone.vy = value;
            else if(axis == "z") drone.vz = value;
        }
    }

    cout << "Drone struct updated successfully.\n\n";
    cout << DroneState() << endl;
}

void encryptDecrypt(char *data, size_t len){
    for(size_t i = 0; i < len; i++) data[i] ^= XOR_KEY;
}

void handleControlCommands(int server_fd){
    char buffer[BUFFER_SIZE];
    struct sockaddr_in client_addr;
    socklen_t addr_len = sizeof(client_addr);

    while(true){
        int n = recvfrom(server_fd, buffer, BUFFER_SIZE, 0, (struct sockaddr*)&client_addr, &addr_len);
        if(n > 0){
            encryptDecrypt(buffer, n);
            lock_guard<std::mutex> lock(console_mutex);
            cout << "Received Control Command! " << string(buffer, n) << endl;
            string command = string(buffer, n);
            if (command == "fetch") sendFileToServer();
            else if (command == "quit") exit(0);
            else updateDroneInformation(command);
        }
    }
}

void sendFileToServer(void){
    // We need to call the python file with the respective information
    string command = "python3 helper/QUICHelper/examples/http3_client.py --ca-certs helper/QUICHelper/tests/pycacert.pem https://localhost:" + to_string(UUID + 2) + "/ --fileName ./DroneData/" + to_string(UUID);
    system(command.c_str());
}

string DroneState(void){
    stringstream ss;
    ss << "Current Telemetry Data of Drone\n";
    ss << "x = " << drone.x << " " << ", y = " << drone.y << " " << ", z = " << drone.z << endl;
    ss << "vx = " << drone.vx << " " << ", vy = " << drone.vy << " " << ", vz = " << drone.vz << endl;
    ss << "state = " << drone.state << endl;
    return ss.str();
}

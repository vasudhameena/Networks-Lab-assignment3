#include <boost/asio.hpp>
#include <iostream>
#include <thread>
#include <vector>
#include <cstdlib>
#include <cstring>
#include <chrono>
#include <random>
#include <zlib.h>

using boost::asio::ip::tcp;

#define SERVER_IP "127.0.0.1"
#define SERVER_PORT 12345

std::random_device rd; // Obtain a random number from hardware
std::mt19937 gen(rd()); // Seed the generator
std::uniform_int_distribution<> dist_weather(0, 50); // Range for weather data
std::uniform_int_distribution<> dist_congestion(0, 15); // Randomly simulate congestion

// Function to generate random weather data
std::string generateRandomWeatherData() {
    int temperature = dist_weather(gen); // Random temperature between 0 and 100
    int humidity = dist_weather(gen); // Random humidity between 0 and 100
    return "Temperature: " + std::to_string(temperature) + "°C, Humidity: " + std::to_string(humidity) + "%";
}

void compressData(const std::string& input, std::vector<char>& compressedData) {
    uLong sourceLen = input.size();
    uLong destLen = compressBound(sourceLen); // Initial size for compressed data

    compressedData.resize(destLen); // Allocate enough space for compressed data

    int result = compress(reinterpret_cast<Bytef*>(compressedData.data()), &destLen,
                          reinterpret_cast<const Bytef*>(input.data()), sourceLen);

    if (result != Z_OK) {
        std::cerr << "Compression failed with error code: " << result << std::endl;
        compressedData.clear(); // Clear the vector if compression fails
        return;
    }

    compressedData.resize(destLen); // Resize to actual compressed size
}


void tcpRenoCongestionControl(int& cwnd, int& ssthresh, bool networkCongested) {
    if (!networkCongested) {
        ssthresh = cwnd / 2;
        cwnd = 1;
    } else {
        if (cwnd < ssthresh) {
            cwnd *= 2; // Slow start: exponential growth
        } else {
            cwnd += 1; // Congestion avoidance: linear growth
        }
    }
}

void sendWeatherData() {
    try {
        boost::asio::io_context io_context;
        tcp::socket socket(io_context);
        socket.connect(tcp::endpoint(boost::asio::ip::make_address(SERVER_IP), SERVER_PORT));

        int cwnd = 1;
        int ssthresh = 64;

        while (true) {
            // Generate random weather data
            std::string weather_data = generateRandomWeatherData();
            std::vector<char> compressed_data;
            compressData(weather_data, compressed_data);

            // Simulate sending based on congestion window
            size_t dataSize = compressed_data.size();
            size_t sentBytes = 0;
            while (sentBytes < dataSize) {
                size_t bytesToSend = std::min(static_cast<size_t>(cwnd * 1024), dataSize - sentBytes);
                boost::system::error_code error;
                size_t bytesSent = boost::asio::write(socket, boost::asio::buffer(compressed_data.data() + sentBytes, bytesToSend), error);

                if (error) {
                    std::cerr << "Error sending data: " << error.message() << std::endl;
                    return;
                }

                sentBytes += bytesSent;
            }

            // Read acknowledgment
            std::vector<char> ack_buffer(3);
            boost::system::error_code error;
            size_t ack_length = socket.read_some(boost::asio::buffer(ack_buffer), error);

            if (error) {
                std::cerr << "Error receiving acknowledgment: " << error.message() << std::endl;
            } else {
                std::string ack_message(ack_buffer.begin(), ack_buffer.begin() + ack_length);
                std::cout << "Received acknowledgment: " << ack_message << std::endl;
            }

            // Simulate network congestion detection based on `cwnd`
            bool networkCongested = rand() % 15; // Randomly simulate congestion

            // Adjust sending rate based on congestion control
            tcpRenoCongestionControl(cwnd, ssthresh, networkCongested);

            std::cout << "Sent weather data: " << weather_data << std::endl;
            std::cout << "Congestion window (cwnd): " << cwnd << std::endl;
            std::cout << "Slow start threshold (ssthresh): " << ssthresh << std::endl;
            std::cout << "Network congestion status: " << ((networkCongested!=0) ? "Not Congested" : "Congested") << std::endl;

            std::this_thread::sleep_for(std::chrono::seconds(5));
        }
    } catch (std::exception& e) {
        std::cerr << "Client error: " << e.what() << std::endl;
    }
}

int main() {
    std::thread client_thread(sendWeatherData);
    client_thread.join();

    return 0;
}

#include <boost/asio.hpp>
#include <iostream>
#include <thread>
#include <vector>
#include <zlib.h>  // Include zlib for compression and decompression
#include<string>
using boost::asio::ip::tcp;

#define SERVER_PORT 12345


void decompressData(const std::vector<char>& compressedData, std::string& output) {
    // Estimate the size of the decompressed data (this may need adjustment if not accurate)
    uLong sourceLen = compressedData.size();
    uLong destLen = sourceLen * 4; // Initial guess (may need adjustment based on your data)

    std::vector<char> decompressedData(destLen);

    // Attempt decompression
    int result = uncompress(reinterpret_cast<Bytef*>(decompressedData.data()), &destLen,
                            reinterpret_cast<const Bytef*>(compressedData.data()), sourceLen);

    // Handle decompression result
    if (result == Z_OK) {
        // Resize to the actual decompressed size
        decompressedData.resize(destLen);
        output.assign(decompressedData.begin(), decompressedData.end());
    } else {
        std::cerr << "Decompression failed with error code: " << result << std::endl;
        output.clear(); // Clear the output string if decompression fails
    }
}

// Function to print client information
void printClientInfo(const tcp::socket& socket) {
    // Get the remote endpoint (client) information
    std::string client_ip = socket.remote_endpoint().address().to_string();
    unsigned short client_port = socket.remote_endpoint().port();

    std::cout << "Client connected from IP: " << client_ip
              << " and Port: " << client_port << std::endl;
}

// Session handling function for each client connection
void session(tcp::socket socket) {
    try {
        // Print client information
        printClientInfo(socket);

        while (true) {
            std::vector<char> buffer(1024);
            boost::system::error_code error;
            size_t length = socket.read_some(boost::asio::buffer(buffer), error);

            if (error == boost::asio::error::eof) {
                break; // Connection closed cleanly by peer
            } else if (error) {
                throw boost::system::system_error(error); // Some other error
            }

            // Decompress the received data
            std::string received_data;
            decompressData(std::vector<char>(buffer.begin(), buffer.begin() + length), received_data);

            // Print client info along with the decompressed data
            std::string client_ip = socket.remote_endpoint().address().to_string();
            unsigned short client_port = socket.remote_endpoint().port();
            std::cout << "Received data from IP: " << client_ip
                      << " Port: " << client_port << " - Data: " << received_data << std::endl;

            // Send acknowledgment
            std::string ack_message = "ACK";
            boost::asio::write(socket, boost::asio::buffer(ack_message), error);
            if (error) {
                throw boost::system::system_error(error);
            }
            std::cout << "Sent acknowledgment to IP: " << client_ip
                      << " Port: " << client_port << " - Message: " << ack_message << std::endl;
        }
    } catch (std::exception& e) {
        std::cerr << "Server error: " << e.what() << std::endl;
    }
}

// Main function to set up the server
int main() {
    try {
        boost::asio::io_context io_context;
        tcp::acceptor acceptor(io_context, tcp::endpoint(tcp::v4(), SERVER_PORT));

        while (true) {
            tcp::socket socket(io_context);
            acceptor.accept(socket);
            std::thread(session, std::move(socket)).detach(); // Detach each session to handle clients concurrently
        }
    } catch (std::exception& e) {
        std::cerr << "Server error: " << e.what() << std::endl;
    }

    return 0;
}

# Weather Data Client-Server Application

This project is a client-server application that simulates the transmission of weather data using Boost.Asio and Zlib. The client generates random weather data, compresses it using Zlib, and sends it to the server. The server receives the data, prints the client's information, and sends an acknowledgment.

## Features

- **Client:** 
  - Generates random weather data (temperature and humidity).
  - Compresses data using Zlib before sending.
  - Implements TCP Reno congestion control algorithm for dynamic adjustment of sending rate.
  
- **Server:** 
  - Receives weather data from the client.
  - Prints the data and the client's IP and port information.
  - Sends acknowledgment back to the client.

## Requirements

- C++ compiler supporting C++11 or later.
- Boost.Asio library.
- Zlib library.

## Installation

### Dependencies

Ensure you have the following dependencies installed:

- **Boost.Asio**: Used for network communication.
- **Zlib**: Used for compressing the weather data.

On Linux, you can install these using:

```bash
sudo apt-get install libboost-all-dev zlib1g-dev
